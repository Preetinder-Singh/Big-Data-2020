#Preetinder 170040
import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams["figure.figsize"] = [10, 6]
plt.xlabel("Items")
plt.ylabel("Sales")

data = pd.read_csv("E:/SD\Sem-7/Big Data & Data Analytics - 2/Week10/Project/BreadBasket_DMS.csv")

items = data.set_index(['Item'])
NewItems= items.drop(['NONE'])
NewItems.reset_index(inplace = True)
print("Question 1")
Top = NewItems['Item'].value_counts()
print("\nFrequency of top 10 selling items: \n")
print(Top.head(10))

Top.head(10).plot(kind='bar', color='red')
plt.show()


